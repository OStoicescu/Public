﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace ABM_Developer_Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FindLOCs();
        }

        private void FindLOCs()
        {

            string input = @"UNA:+.? '
                UNB + UNOC:3 + 2021000969 + 4441963198 + 180525:1225 + 3VAL2MJV6EH9IX + KMSV7HMD + CUSDECU - IE++1++1'
                UNH + EDIFACT + CUSDEC:D: 96B: UN: 145050'
                BGM + ZEM:::EX + 09SEE7JPUV5HC06IC6 + Z'
                LOC + 17 + IT044100'
                LOC + 18 + SOL'
                LOC + 35 + SE'
                LOC + 36 + TZ'
                LOC + 116 + SE003033'
                DTM + 9:20090527:102'
                DTM + 268:20090626:102'
                DTM + 182:20090527:102'";

            string[] arrOut = null;

            Parse(input, new char[] { '\r', '\n' }, new char[] { '+' }, "LOC", 1, 2, ref arrOut);
            if (arrOut != null)
            {
                for (var i = 0; i <= arrOut.Length - 1; i++)
                {
                    Console.WriteLine(arrOut[i]);
                }
            }
        }

        private void Parse(string input, char[] psDelimiter1, char[] psDelimiter2, string sFind, int position1, int position2, ref string[] arrOut)
        {
            ArrayList arrList = new ArrayList();
            string[] parsed = input.Split(psDelimiter1);

            for (int i = 0; i < parsed.Length - 1; i++)
            {
                if (parsed[i].TrimStart().StartsWith(sFind))
                {

                    string[] parsed2 = parsed[i].TrimStart().Split(psDelimiter2);

                    if (parsed2.Length > position1) { arrList.Add(parsed2[position1]); };
                    if (parsed2.Length > position2) { arrList.Add(parsed2[position2]); };
                }

            }

            arrOut = (string[])arrList.ToArray(typeof(string));
        }

        private void button2_Click(object sender, EventArgs e)
        {

            List<string> listOut = new List<string>();
            List<string> listIn = new List<string>() ;
            listIn.Add("MWB");
            listIn.Add("TRV");
            listIn.Add("CAR");

            FindInXML(listIn, ref listOut);
            if (listOut != null)
            {
                Console.WriteLine("1st method");
                foreach (var str in listOut)
                {
                    Console.WriteLine(str);
                }
            }

            listOut.Clear();
            FindInXML2(listIn, ref listOut);
            if (listOut != null)
            {
                Console.WriteLine("2nd method");
                foreach (var str in listOut)
                {
                    Console.WriteLine(str);
                }
            }
       }

        private void FindInXML2(List<string> input, ref List<string> output)
        {
            string filePath = "";
            var currentDirectory = SolutionDirectoryHelper.SolutionDirectoryInfo();
            if (currentDirectory != null)
            {
                filePath = Path.Combine(SolutionDirectoryHelper.SolutionDirectoryInfo().FullName, "XML\\TEST.XML");
                if (File.Exists(filePath))
                {

                    XDocument doc = XDocument.Load(filePath);

                    if (doc != null)
                    {
                        foreach (var search in input)
                        {
                            List<string> searchList = doc
                               .Elements("InputDocument")
                               .Elements("DeclarationList")
                               .Elements("Declaration")
                               .Elements("DeclarationHeader")
                               .Elements("Reference")
                               .Where(x => x.Attribute("RefCode").Value == search.ToString())
                               .Select(x => (string)x)
                               .ToList();

                            if (searchList != null)
                            {
                                foreach (var item in searchList)
                                {
                                    output.Add(item);
                                }
                            }
                        }
                    }
                }
            }
        }

        private void FindInXML(List<string> input, ref List<string> output)
        {
            string filePath = "";
            var currentDirectory = SolutionDirectoryHelper.SolutionDirectoryInfo();
            if (currentDirectory != null)
            {
                filePath = Path.Combine(SolutionDirectoryHelper.SolutionDirectoryInfo().FullName, "XML\\TEST.XML");
                if (File.Exists(filePath))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(filePath);

                    if (doc != null)
                    {
                        XmlNodeList referenceNodes = doc.SelectNodes("//InputDocument/DeclarationList/Declaration/DeclarationHeader/Reference");
                        foreach (var search in input)
                        {
                            foreach (XmlNode referenceNode in referenceNodes)
                            {
                                if (referenceNode.Attributes["RefCode"].Value == search)
                                {
                                    string value = referenceNode.InnerText;
                                    output.Add(value);
                                }
                            }
                        }
                    }
                }
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            //CreateSchemaHelper();

            ABM.ABMTest instance = new ABM.ABMTest();

            string filePath = "";
            var currentDirectory = SolutionDirectoryHelper.SolutionDirectoryInfo();
            if (currentDirectory != null)
            {
                filePath = Path.Combine(SolutionDirectoryHelper.SolutionDirectoryInfo().FullName, "XML\\WEBSERVICEINPUT.XML");
                if (File.Exists(filePath))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(filePath);

                    if (doc != null)
                    {
                        int returnCode = instance.ValidateInput(doc);
                        Console.WriteLine("return Code: " + returnCode.ToString());
                    }
                }
            }

        }
        private void CreateSchemaHelper()
        {

            string filePath = "";
            var currentDirectory = SolutionDirectoryHelper.SolutionDirectoryInfo();
            if (currentDirectory != null)
            {
                filePath = Path.Combine(SolutionDirectoryHelper.SolutionDirectoryInfo().FullName, "XML\\WEBSERVICEINPUT.XML");
                if (File.Exists(filePath))
                {
                    XmlReader xmlReader = XmlReader.Create(filePath);
                    XmlSchemaSet schemaSet = new XmlSchemaSet();
                    XmlSchemaInference schemaInference = new XmlSchemaInference();
                    schemaSet = schemaInference.InferSchema(xmlReader);
                    foreach (XmlSchema schema in schemaSet.Schemas())
                    {
                        schema.Write(Console.Out);
                    }

                    if (xmlReader != null)
                    {
                        xmlReader.Close();
                        xmlReader.Dispose();
                    }
                }
            }
        }
    }
}

public static class SolutionDirectoryHelper
{
    public static DirectoryInfo SolutionDirectoryInfo(string RootPath = null)
    {
        var currentDirectory = new DirectoryInfo(RootPath ?? Directory.GetCurrentDirectory());
        while (currentDirectory != null && !currentDirectory.GetFiles("*.sln").Any())
        {
            currentDirectory = currentDirectory.Parent;
        }
        return currentDirectory;
    }
}