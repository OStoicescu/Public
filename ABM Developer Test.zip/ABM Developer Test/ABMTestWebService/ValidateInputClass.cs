﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace ABMTestWebService
{
    public class ValidateInputClass
    {
        public static Int32 Validate(XmlDocument input)
        {
            XmlTextReader schemaReader=null;
            try
            {
                Control instance = new Control();
                string schemaPath = HttpContext.Current.Server.MapPath( instance.ResolveUrl("~") + "Schema/WEBSERVICEINPUT.xsd");

                schemaReader = new XmlTextReader(schemaPath);
                var schema = new XmlSchemaSet();
                schema.Add(null, schemaReader);

                var settings = new XmlReaderSettings();
                settings.ValidationType = ValidationType.Schema;
                settings.Schemas.Add(schema);
                settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
                settings.ValidationEventHandler += new ValidationEventHandler(SchemaValidationEventHandler);

                var doc = new XmlDocument();
                doc.Load(XmlReader.Create(new StringReader(input.InnerXml), settings));

                ValidationEventHandler eventHandler = new ValidationEventHandler(SchemaValidationEventHandler);
                doc.Validate(eventHandler);

                XmlNode commandNode = input.SelectSingleNode("//InputDocument/DeclarationList/Declaration");
                if (commandNode.Attributes !=null && commandNode.Attributes.Count>0 && commandNode.Attributes["Command"] != null && commandNode.Attributes["Command"].Value!="DEFAULT")
                {
                    return -1;
                }

                XmlNode siteNode = input.SelectSingleNode("//InputDocument/DeclarationList/Declaration/DeclarationHeader/SiteID");
                //if (siteNode != null && siteNode.ChildNodes.Count>0 && siteNode.ChildNodes[0].Value != "DUB")
                if (siteNode != null && siteNode.InnerText != "DUB")
                {
                    return -2;
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return -3; //XML validation error against the schema or some other general exception
            }
            finally
            {
                if (schemaReader != null)
                {
                    schemaReader.Close();
                    schemaReader.Dispose();
                }
            }

            return 0;
        }
       static void SchemaValidationEventHandler(object sender, ValidationEventArgs e)
        {
            switch (e.Severity)
            {
                case XmlSeverityType.Error:
                    Console.WriteLine("Error: {0}", e.Message);
                    throw new Exception("Invalid XML - " + e.Message);
                case XmlSeverityType.Warning:
                    Console.WriteLine("Warning {0}", e.Message);
                    break;
            }
        }
    }
}