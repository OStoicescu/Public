﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Xml;

namespace ABMTestWebService
{
    public class ABMTest : System.Web.Services.WebService
    {
        [WebMethod]
        public Int32 ValidateInput(XmlDocument input)
        {
           return ValidateInputClass.Validate(input);
        }
    }
}
